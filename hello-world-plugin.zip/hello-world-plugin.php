<?php
/*
Plugin Name: Hello World Plugin
Plugin URI: https://example.com/
Description: A simple Hello World plugin to test the wp-starter template.
Version: 1.0
Author: Your Name
Author URI: https://yourwebsite.com/
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: hello-world-plugin
*/

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

// Plugin logic
function hello_world_plugin_function() {
    echo '<p>Hello World!</p>';
}

add_action('wp_footer', 'hello_world_plugin_function');
